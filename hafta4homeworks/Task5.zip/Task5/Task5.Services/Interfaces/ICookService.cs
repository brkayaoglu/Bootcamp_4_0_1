﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Task5.Domain.Interfaces;
using Task5.Domain.Response.CooksResponse;

namespace Task5.Services.Interfaces
{
    public interface ICookService
    {
        Task<List<CookResponse>> GetCooks();

        Task<CookResponse> GetCook(Expression<Func<Cook, bool>> expression);
        Task<CookResponse> GetCook(int id);

    }
}
