﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Task5.Domain.Interfaces;
using Task5.Domain.Response;

namespace Task5.Services.Interfaces
{
    public interface IRecipeService
    {
        Task<List<RecipeResponse>> GetRecipes();

        Task<RecipeResponse> GetRecipe(Expression<Func<Recipe, bool>> expression);
        Task<RecipeResponse> GetRecipe(int id);
        Task<RecipeResponse> AddRecipe(Recipe recipe);
        Task<bool> DeleteRecipe(int id);

        Task<RecipeResponse> UpdateRecipe(Recipe recipe);

    }
}
