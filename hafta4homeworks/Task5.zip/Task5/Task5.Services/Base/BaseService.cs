﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task5.Services.Base
{
    public class BaseService
    {
    }
}
