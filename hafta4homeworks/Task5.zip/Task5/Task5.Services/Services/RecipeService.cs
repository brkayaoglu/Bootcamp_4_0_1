﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Task5.Data.Repositories.Interface;
using Task5.Domain.Interfaces;
using Task5.Domain.Response;
using Task5.Services.Interfaces;

namespace Task5.Services.Services
{
    public class RecipeService : IRecipeService
    {

        private readonly IRecipeRepository _recipeRepository;

        public RecipeService(IRecipeRepository recipeRepository)
        {
            _recipeRepository = recipeRepository;
        }

        public async Task<RecipeResponse> AddRecipe(Recipe recipe)
        {
            var result = await _recipeRepository.Add(recipe);


            return new RecipeResponse
            {
                Id = result.Id,
                Cook = result.Cook
            };
        }

        public async Task<bool> DeleteRecipe(int id)
        {
            var result = await _recipeRepository.Delete(id);

            return result;
        }

        public async Task<RecipeResponse> GetRecipe(Expression<Func<Recipe, bool>> expression)
        {
            var result = await _recipeRepository.Get(expression);


            return new RecipeResponse
            {
                Id = result.Id,
                Cook = result.Cook
            };
        }

        public async Task<RecipeResponse> GetRecipe(int id)
        {
            var result = await _recipeRepository.GetById(id);


            return new RecipeResponse
            {
                Id = result.Id,
                Cook = result.Cook
            };
        }

        public async Task<List<RecipeResponse>> GetRecipes()
        {
            var result = await _recipeRepository.GetAll();


            return result.Select(c => new RecipeResponse
            {
                Cook = c.Cook,
                Id = c.Id
            }).ToList();
        }

        public async Task<RecipeResponse> UpdateRecipe(Recipe recipe)
        {
            var result = await _recipeRepository.Update(recipe);


            return new RecipeResponse
            {
                Id = result.Id,
                Cook = result.Cook
            };
        }
    }
}
