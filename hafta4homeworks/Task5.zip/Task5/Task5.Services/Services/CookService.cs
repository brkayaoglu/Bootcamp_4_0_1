﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Task5.Data.Repositories.Interface;
using Task5.Domain.Interfaces;
using Task5.Domain.Response.CooksResponse;
using Task5.Services.Interfaces;

namespace Task5.Services.Services
{
    public class CookService : ICookService
    {

        private readonly ICookRepository _cookRepository;

        public CookService(ICookRepository cookRepository)
        {
            _cookRepository = cookRepository;
        }
        public async Task<CookResponse> GetCook(Expression<Func<Cook, bool>> expression)
        {
            var result = await _cookRepository.Get(expression);


            return new CookResponse
            {
                Id = result.Id,
                FullName = string.Concat(result.FirstName, result.LastName),
                NumberOfRecipies = result.NumberOfRecipes,
            };
        }

        public async Task<CookResponse> GetCook(int id)
        {
            var result = await _cookRepository.GetById(id);

            return new CookResponse
            {
                Id = result.Id,
                FullName = string.Concat(result.FirstName, result.LastName),
                NumberOfRecipies = result.NumberOfRecipes,
            };
        }

        public async Task<List<CookResponse>> GetCooks()
        {
            var result = await _cookRepository.GetAll();

            return result.Select(c => new CookResponse
            {
                Id = c.Id,
                FullName = string.Concat(c.FirstName, c.LastName),
                NumberOfRecipies = c.NumberOfRecipes
            }).ToList();
        }
    }
}
