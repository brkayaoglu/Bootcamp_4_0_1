﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Task5.Domain.Interfaces;
using Task5.Domain.Response;
using Task5.Services.Interfaces;

namespace Task5.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RecipesController : ControllerBase
    {
        private readonly ILogger<RecipesController> _logger;
        private readonly IRecipeService _recipeService;

        public RecipesController(ILogger<RecipesController> logger,
                                   IRecipeService recipeService)
        {
            _logger = logger;
            _recipeService = recipeService;
        }


        [HttpGet]
        [ProducesResponseType(typeof(RecipeResponse), StatusCodes.Status200OK)]
        public async Task<IActionResult> Get()
        {
            var recipes = await _recipeService.GetRecipes();
            return Ok(recipes);
        }

        [HttpGet("{id}")]
        [ProducesResponseType(typeof(RecipeResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RecipeResponse), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Get(int id)
        {
            var recipe = await _recipeService.GetRecipe(id);

            if (recipe == null)
                return NotFound();

            return Ok(recipe);
        }

        [HttpPost]
        [Route("AddRecipe")]
        public async Task<IActionResult> Post([FromBody] Recipe recipe)
        {
            var addedRecipe = await _recipeService.AddRecipe(recipe);

            if (recipe == null)
                return NotFound();

            return Ok(recipe);
        }

        [ProducesResponseType(typeof(RecipeResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RecipeResponse), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Put([FromBody] Recipe recipe)
        {
            var updatedRecipe = await _recipeService.UpdateRecipe(recipe);

            if (updatedRecipe == null)
                return BadRequest();

            return Ok(updatedRecipe);

        }

        [HttpDelete("{id}")]
        
        public async Task<IActionResult> Delete(int id)
        {
            var deletedRecipe = await _recipeService.DeleteRecipe(id);

            if (deletedRecipe == false)
                return BadRequest();

            return Ok();

        }

    }
}
