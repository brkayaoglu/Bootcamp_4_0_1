﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Task5.Domain.Response.CooksResponse;
using Task5.Services.Interfaces;

namespace Task5.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CooksController : ControllerBase
    {
        private readonly ILogger<CooksController> _logger;
        private readonly ICookService _cookService;

        public CooksController(ILogger<CooksController> logger,
                                   ICookService cookService)
        {
            _logger = logger;
            _cookService = cookService;
        }


        [HttpGet]
        [ProducesResponseType(typeof(CookResponse), StatusCodes.Status200OK)]
        public async Task<IActionResult> Get()
        {
            var cooks = await _cookService.GetCooks();
            return Ok(cooks);
        }

        [HttpGet("{id}")]
        [ProducesResponseType(typeof(CookResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CookResponse), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Get(int id)
        {
            //var customer = await _customerService.GetCustomer(c => c.Id == id);
            var cook = await _cookService.GetCook(id);

            if (cook == null)
                return NotFound();

            return Ok(cook);
        }

    }
}
