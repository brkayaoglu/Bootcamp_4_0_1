﻿using Microsoft.Extensions.DependencyInjection;
using Task5.Data.Repositories.Interface;
using Task5.Data.Repositories.Derived;
using Task5.Services.Interfaces;
using Task5.Services.Services;

namespace Task5.Extensions
{
    public static class ServicesConfigurationExtensions
    {
        public static void AddProjectRepositories(this IServiceCollection services)
        {
            services.AddScoped<ICookRepository, CookRepository>();
            services.AddScoped<IRecipeRepository, RecipeRepository>();
        }

        public static void AddProjectServices(this IServiceCollection services)
        {
            services.AddTransient<ICookService, CookService>();
            services.AddTransient<IRecipeService, RecipeService>();
        }
    }
}
