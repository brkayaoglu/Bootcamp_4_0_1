﻿using System;
using System.Collections.Generic;
using System.Text;
using Task5.Data.Repositories.Core;
using Task5.Domain.Interfaces;

namespace Task5.Data.Repositories.Interface
{
    public interface IRecipeRepository : IReadRepository<Recipe>, IWriteRepository<Recipe>
    {
    }
}
