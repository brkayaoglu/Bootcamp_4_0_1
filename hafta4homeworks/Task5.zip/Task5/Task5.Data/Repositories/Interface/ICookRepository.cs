﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Task5.Data.Repositories.Core;
using Task5.Domain.Interfaces;

namespace Task5.Data.Repositories.Interface
{
    public interface ICookRepository : IReadRepository<Cook>, IWriteRepository<Cook>
    {
        
    }
}
