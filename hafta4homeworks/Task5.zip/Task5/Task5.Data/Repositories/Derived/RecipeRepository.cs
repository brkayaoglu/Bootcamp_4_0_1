﻿using Task5.Data.Repositories.Core;
using Task5.Data.Repositories.Interface;
using Task5.Domain.Interfaces;

namespace Task5.Data.Repositories.Derived
{
    public class RecipeRepository : RepositoryBase<Recipe>, IRecipeRepository
    {
    }
}
