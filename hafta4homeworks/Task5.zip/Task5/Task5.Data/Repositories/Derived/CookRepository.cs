﻿using System.Linq;
using System.Threading.Tasks;
using Task5.Data.Repositories.Core;
using Task5.Data.Repositories.Interface;
using Task5.Domain.Interfaces;

namespace Task5.Data.Repositories.Derived
{
    public class CookRepository : RepositoryBase<Cook>, ICookRepository
    {
        
    }
}
