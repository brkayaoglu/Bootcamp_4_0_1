﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Task5.Domain.Interfaces;

namespace Task5.Data.EntityConfiguration
{
    public class CookConfiguration : IEntityTypeConfiguration<Cook>
    {
        public void Configure(EntityTypeBuilder<Cook> builder)
        {
            builder.ToTable("Cooks");
            builder.HasKey(p => p.Id);
        }
    }
}
