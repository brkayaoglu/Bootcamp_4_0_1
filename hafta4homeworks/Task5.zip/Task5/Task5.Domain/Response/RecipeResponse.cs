﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task5.Domain.Response
{
    public class RecipeResponse
    {
        public int Id { get; set; }

        public string Cook { get; set; }
    }
}
