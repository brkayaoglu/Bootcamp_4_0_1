﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task5.Domain.Interfaces
{
    public class Recipe : IEntity
    {
        public int Id { get; set; }

        public string Cook { get; set; }

    }
}
