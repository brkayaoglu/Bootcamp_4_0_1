﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task5.Domain.Interfaces
{
    public interface IEntity
    {
        public int Id { get; set; }
    }
}
